#ifndef ERROR_H
#define ERROR_H

extern void warning_msg(const char *fmt, ...);

extern void error_exit(const char *fmt, ...);
#endif
