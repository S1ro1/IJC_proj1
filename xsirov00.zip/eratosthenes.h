#ifndef ERATHOSTENES_1_H
#define ERATHOSTENES_1_H

#include "bitset.h"

extern void Eratosthenes(bitset_t arr);

#endif